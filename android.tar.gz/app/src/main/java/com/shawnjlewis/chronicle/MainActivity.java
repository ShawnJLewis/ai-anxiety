package com.shawnjlewis.chronicle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
